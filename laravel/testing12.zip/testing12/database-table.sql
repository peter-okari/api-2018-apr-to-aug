CREATE TABLE `jaribus` (
  `jaribu_id` int(11) NOT NULL AUTO_INCREMENT,
  `jaribu_name` varchar(45) DEFAULT NULL,
  `created_at` datetime DEFAULT NULL,
  `updated_at` datetime DEFAULT NULL,
  PRIMARY KEY (`jaribu_id`)
) ENGINE=InnoDB;
