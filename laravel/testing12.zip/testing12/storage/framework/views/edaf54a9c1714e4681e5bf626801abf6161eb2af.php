;

<?php $__env->startSection('content'); ?>

<div class="columns">

  <div class="column is-10 is-offset-1">
    <h3>Add</h3>
    <?php if($errors->any()): ?>
    <div class="notification is-danger">
      <button class="delete"></button>
      <ul>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

        <li><?php echo e($error); ?></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </ul>
    </div>
    <?php endif; ?>
    <form name='frm' method='post' action="<?php echo e(URL::to('save')); ?>">

      <?php echo e(csrf_field()); ?>


      <div class="input-field">
        <label class="field">
          <input type="text" class="input" name="jname" placeholder="name">
        </label>
      </div>

      <label class="field">
        <input type="submit" name="submit" class="button is-primary">
      </label>

    </form>
    <br/>
    <h3>My List</h3>
    <table class="table is-striped">
      <thead>
        <tr>
          <th>#</th>
          <th>Name</th>
          <th>Action</th>
        </tr>
      </thead>
      <tbody>
        <?php $__currentLoopData = $rows; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $row): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
          <td><?php echo e($row->jaribu_id); ?></td>
          <td><?php echo e($row->jaribu_name); ?></td>
          <td><a href="<?php echo e(URL::to('delete').'/'.$row->jaribu_id); ?>"> <i class="fa fa-trash" aria-hidden="true"></i> </a></td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
      </tbody>
    </table>
  </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('welcome', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>